package CapaPersistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import CapaLogica.Docente;
import CapaLogica.Licencia;

public class GestorDAO {
    private ConexionBD conexion = new ConexionBD();

    public void insertarDocenteYLicencia(Docente d, Licencia l) throws SQLException {
        try (Connection conn = conexion.conectar()) {
            String sql = "INSERT INTO inasistenciadocente (ci, nombre, apellido, curso, grupo, turno, tipoLicencia, fechaInicio, fechaFin) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, d.getCi());
            ps.setString(2, d.getNombre());
            ps.setString(3, d.getApellido());
            ps.setInt(4, d.getCurso());
            ps.setString(5, d.getGrupo());
            ps.setString(6, d.getTurno());
            ps.setString(7, l.getTipoLicencia());
            ps.setDate(8, l.getFechaInicio());
            ps.setDate(9, l.getFechaFin());
            ps.executeUpdate();
            ps.close();
        }
    }

  public void eliminarDocentePorCI(String ci) throws SQLException {
    try (Connection conn = conexion.conectar()) {
        String sql = "DELETE FROM inasistenciadocente WHERE ci = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, ci);
        ps.executeUpdate();
        ps.close();
    }
}

   

    public void eliminarTodosLosDocentes() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
