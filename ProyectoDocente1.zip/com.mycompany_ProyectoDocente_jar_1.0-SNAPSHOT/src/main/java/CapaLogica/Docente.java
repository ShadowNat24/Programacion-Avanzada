package CapaLogica;

public class Docente {
    private String ci, nombre, apellido, grupo, turno;
    private int curso;

    public Docente(String ci, String nombre, String apellido, int curso, String grupo, String turno) {
        this.ci = ci;
        this.nombre = nombre;
        this.apellido = apellido;
        this.curso = curso;
        this.grupo = grupo;
        this.turno = turno;
    }

    public String getCi() { return ci; }
    public String getNombre() { return nombre; }
    public String getApellido() { return apellido; }
    public int getCurso() { return curso; }
    public String getGrupo() { return grupo; }
    public String getTurno() { return turno; }
}
