package CapaLogica;

import java.sql.Date;

public class Licencia {
    private String tipoLicencia;
    private Date fechaInicio, fechaFin;

    public Licencia(String tipoLicencia, Date fechaInicio, Date fechaFin) {
        this.tipoLicencia = tipoLicencia;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
    }

    public String getTipoLicencia() { return tipoLicencia; }
    public Date getFechaInicio() { return fechaInicio; }
    public Date getFechaFin() { return fechaFin; }
}
