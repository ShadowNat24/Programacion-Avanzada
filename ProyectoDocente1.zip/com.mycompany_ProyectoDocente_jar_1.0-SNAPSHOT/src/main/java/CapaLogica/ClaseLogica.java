package CapaLogica;

import CapaPersistencia.GestorDAO;
import java.sql.Date;

public class ClaseLogica {
    public void guardar(String ci, String nombre, String apellido, int curso, String grupo, String turno,
                        String tipoLicencia, Date fechaInicio, Date fechaFin) throws Exception {
        Docente d = new Docente(ci, nombre, apellido, curso, grupo, turno);
        Licencia l = new Licencia(tipoLicencia, fechaInicio, fechaFin);
        GestorDAO dao = new GestorDAO();
        dao.insertarDocenteYLicencia(d, l);
    }
}


